package com.credibanco.iso_parser.application.utils;

public class MaskUtil {

    public static String maskTrace(String trace) {
        trace = maskCard(trace);
        trace = maskCvv(trace);
        return trace;
    }

    public static String maskCvv(String trace) {
        String finalMask = trace;
        if (trace.contains("! C000026")) {
            finalMask = trace.replaceAll("! C000026 \\d{3}", "! C000026 ***");
            finalMask = finalMask.replaceAll("! C000026 \\*\\*\\*\\d", "! C000026 ****");
        }
        return finalMask;
    }

    public static String maskCard(String trace) {
        if (trace.contains("=")) {
            StringBuilder sb = new StringBuilder(trace);
            int index = sb.indexOf("=");
            if (index > 12) {
                int indexCard = index - 12;
                for (int i = indexCard; i < index; i++) {
                    sb.setCharAt(i, '*');
                }
                return sb.toString();
            }
            return sb.toString();
        }
        return trace;
    }
}
