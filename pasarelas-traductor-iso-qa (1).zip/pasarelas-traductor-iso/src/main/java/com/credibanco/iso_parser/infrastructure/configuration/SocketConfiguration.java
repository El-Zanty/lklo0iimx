package com.credibanco.iso_parser.infrastructure.configuration;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.credibanco.iso_parser.domain.SettingBase24;
import com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.SocketAdapter;
import com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.SocketSmartVista;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class SocketConfiguration {
	
	@Value("${SmartVista.settings}")
	String jsonBase24;
	
	@Value("${SmartVista.echo.frecuency}")
	Long echoFrecuency;
	
	@Value("${SmartVista.reconnect.delay}")
	Long reconnectDelay;

	@Value("${SmartVista.maxRetryConnection}")
	int maxRetryConnection;
	
	@Value("${SmartVista.reset}")
	Boolean reset;

	ObjectMapper objectMapper = new ObjectMapper();
	
	@Bean
	public ExecutorService getExecutorService() {
		return Executors.newCachedThreadPool();
	}
	
	@Bean
	public SocketSmartVista getSocket(SocketAdapter socketAdapter) throws IOException {
		List<SettingBase24> listBase24 = objectMapper.readValue(jsonBase24, new TypeReference<List<SettingBase24>>() {});
		Queue<SocketSmartVista> socketsQueue = new LinkedList<>();
		boolean currentSocketIsAvailable = false;
		SocketSmartVista currentSocket = null;
		
		for (SettingBase24 settingBase24 : listBase24) {
			log.info("Añadiendo Puerto: {}", settingBase24.toString() );
			SocketSmartVista socket = new SocketSmartVista(settingBase24.getIp(), settingBase24.getPort(), reconnectDelay,
					echoFrecuency, socketAdapter, getExecutorService(), maxRetryConnection, reset);
			socketsQueue.add(socket);
		}
		
		while(!currentSocketIsAvailable && !socketsQueue.isEmpty()) {
			currentSocket = socketsQueue.poll();
			log.info("Conectandose a la ip: {} y puerto: {}", currentSocket.getIp(), currentSocket.getPort());
			currentSocketIsAvailable = currentSocket.isAvailable();		
		}
		
		if(currentSocket != null && currentSocketIsAvailable) {
			log.info("Socket disponible ip {} port {}", currentSocket.getIp(), currentSocket.getPort());
			return currentSocket;
		}else {
			log.info("Ningun socket estaba disponible");
			System.exit(0);
			return null;
		}
			
	}

}
