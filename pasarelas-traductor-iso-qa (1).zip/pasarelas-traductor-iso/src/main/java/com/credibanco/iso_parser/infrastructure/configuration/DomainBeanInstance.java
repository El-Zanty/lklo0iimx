package com.credibanco.iso_parser.infrastructure.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.credibanco.iso_parser.application.usecases.AuthorizeTransactionImpl;
import com.credibanco.iso_parser.domain.ports.out.TransactionAuthorizationRepository;
import com.credibanco.iso_parser.application.services.TransactionMapperService;

@Configuration
public class DomainBeanInstance {
	
	@Bean
	public TransactionMapperService getMapperService(FieldsProperties fieldsProperties) {
		return new TransactionMapperService(fieldsProperties);
	}
	
	@Bean
	public AuthorizeTransactionImpl getAuthorizeTransaction(TransactionAuthorizationRepository transactionAuthorizationRepository,
															TransactionMapperService transactionMapperService, ErrorCodes errorCodes) {
		return new AuthorizeTransactionImpl(transactionAuthorizationRepository, transactionMapperService, errorCodes);
	}

}
