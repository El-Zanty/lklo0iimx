package com.credibanco.iso_parser.infrastructure.configuration;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "com.credibanco")
public class ErrorCodes {

	private Map<String, String> svErrorCodes;
}
