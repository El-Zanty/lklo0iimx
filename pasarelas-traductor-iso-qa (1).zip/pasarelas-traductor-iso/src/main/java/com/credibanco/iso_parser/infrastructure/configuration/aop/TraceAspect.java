package com.credibanco.iso_parser.infrastructure.configuration.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class TraceAspect {

    @Around("@annotation(com.credibanco.iso_parser.infrastructure.configuration.aop.Trace)")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        if(log.isTraceEnabled()) {
            try {
                MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
                long start = System.currentTimeMillis();
                Object requestBody = joinPoint.getArgs();
                log.trace("{} - Request parserToIso = {}", methodSignature.getName(), requestBody);

                Object result = joinPoint.proceed();
                long finish = System.currentTimeMillis();
                long timeElapsed = finish - start;
                log.trace("{} - Response: {} ", methodSignature.getName(), result);
                log.trace("{} - time elapsed: {}ms", methodSignature.getName(), timeElapsed);

                return result;
            } catch (Exception e) {
                throw e;
            }
        } else {
            try{
                Object result = joinPoint.proceed();
                return result;
            } catch (Exception e) {
                throw e;
            }

        }

    }
}