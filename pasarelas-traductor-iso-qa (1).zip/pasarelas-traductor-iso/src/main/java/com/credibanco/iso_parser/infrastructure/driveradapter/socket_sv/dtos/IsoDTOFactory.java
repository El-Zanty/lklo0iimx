package com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.dtos;

import com.credibanco.iso_parser.application.utils.HttpIso;
import com.credibanco.iso_parser.domain.FieldIso;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import static com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.dtos.IsoEnums.*;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Supplier;

@Getter
@RequiredArgsConstructor
public enum IsoDTOFactory {

    LOGON(() -> {
    	List<FieldIso> fields = new ArrayList<>();
		fields.add(new FieldIso(0, CUSTOM_HEADER_TITLE.getGetIsoEcoField(), CUSTOM_HEADER_VALUE.getGetIsoEcoField() ));
		fields.add(new FieldIso(0, MESSAGE_TYPE_INDICATOR_TITLE.getGetIsoEcoField(), "0800" ));
		fields.add(new FieldIso(7, TRANSMISSION_DATE_AND_TIME_TITLE.getGetIsoEcoField(), 
				new SimpleDateFormat(SIMPLE_DATE_FORMAT.getGetIsoEcoField()).format(new Date()) ));
		fields.add(new FieldIso(11, SYSTEM_TRACE_AUDIT_NUMBER_TITLE.getGetIsoEcoField(), "" + new SecureRandom().nextInt(900000) ));
		fields.add(new FieldIso(70, NETWORK_MANAGEMENT_INFO_CODE_TITLE.getGetIsoEcoField(), "001"));
		List<FieldIso> fieldsResponse = HttpIso.pack(fields);
		if ( fieldsResponse != null ) {
			return fieldsResponse.get(0).getValue();
		} else {
			return null;
		}
    }),


    LOGON_RESPONSE(() -> {
    	List<FieldIso> fields = new ArrayList<>();
		fields.add( new FieldIso( 0, CUSTOM_HEADER_TITLE.getGetIsoEcoField(), CUSTOM_HEADER_VALUE.getGetIsoEcoField() ));
		fields.add( new FieldIso( 0, MESSAGE_TYPE_INDICATOR_TITLE.getGetIsoEcoField(), "0810" ));
		fields.add( new FieldIso( 7, TRANSMISSION_DATE_AND_TIME_TITLE.getGetIsoEcoField(), 
				new SimpleDateFormat(SIMPLE_DATE_FORMAT.getGetIsoEcoField()).format(new Date()) ));
		fields.add( new FieldIso( 11, SYSTEM_TRACE_AUDIT_NUMBER_TITLE.getGetIsoEcoField(), "" + new SecureRandom().nextInt(900000) ));
		fields.add( new FieldIso( 39, RESPONSE_CODE_TITLE.getGetIsoEcoField(), "00"));
		fields.add( new FieldIso( 70, NETWORK_MANAGEMENT_INFO_CODE_TITLE.getGetIsoEcoField(), "001"));
		List<FieldIso> fieldsResponse = HttpIso.pack(fields);
		if ( fieldsResponse != null ) {
			return fieldsResponse.get(0).getValue();
		} else {
			return null;
		}
    }),

    LOGOFF(()->{
    	List<FieldIso> fields = new ArrayList<>();
		fields.add( new FieldIso( 0, CUSTOM_HEADER_TITLE.getGetIsoEcoField(), CUSTOM_HEADER_VALUE.getGetIsoEcoField() ));
		fields.add( new FieldIso( 0, MESSAGE_TYPE_INDICATOR_TITLE.getGetIsoEcoField(), "0800" ));
		fields.add( new FieldIso( 7, TRANSMISSION_DATE_AND_TIME_TITLE.getGetIsoEcoField(), 
				new SimpleDateFormat(SIMPLE_DATE_FORMAT.getGetIsoEcoField()).format(new Date()) ));
		fields.add( new FieldIso( 11, SYSTEM_TRACE_AUDIT_NUMBER_TITLE.getGetIsoEcoField(), "" + new SecureRandom().nextInt(900000) ));
		fields.add( new FieldIso( 70, NETWORK_MANAGEMENT_INFO_CODE_TITLE.getGetIsoEcoField(), "002"));
		List<FieldIso> fieldsResponse = HttpIso.pack(fields);
		if ( fieldsResponse != null ) {
			return fieldsResponse.get(0).getValue();
		} else {
			return null;
		}
    }),
    LOGOFF_RESPONSE(()-> {
        List<FieldIso> fields = new ArrayList<>();
        fields.add( new FieldIso( 0, CUSTOM_HEADER_TITLE.getGetIsoEcoField(), CUSTOM_HEADER_VALUE.getGetIsoEcoField() ));
        fields.add( new FieldIso( 0, MESSAGE_TYPE_INDICATOR_TITLE.getGetIsoEcoField(), "0810" ));
        fields.add( new FieldIso( 7, TRANSMISSION_DATE_AND_TIME_TITLE.getGetIsoEcoField(), 
        		new SimpleDateFormat(SIMPLE_DATE_FORMAT.getGetIsoEcoField()).format(new Date()) ));
        fields.add( new FieldIso( 11, SYSTEM_TRACE_AUDIT_NUMBER_TITLE.getGetIsoEcoField(), "" + new SecureRandom().nextInt(900000) ));
        fields.add( new FieldIso( 39, RESPONSE_CODE_TITLE.getGetIsoEcoField(), "00"));
        fields.add( new FieldIso( 70, NETWORK_MANAGEMENT_INFO_CODE_TITLE.getGetIsoEcoField(), "002"));
        List<FieldIso> fieldsResponse = HttpIso.pack(fields);

        if ( fieldsResponse != null ) {
            return fieldsResponse.get(0).getValue();
        } else {
            return null;
        }
    }),

    ECO(() -> {
        List<FieldIso> fields = new ArrayList<>();
        fields.add( new FieldIso( 0, CUSTOM_HEADER_TITLE.getGetIsoEcoField(), CUSTOM_HEADER_VALUE.getGetIsoEcoField() ));
        fields.add( new FieldIso( 0, MESSAGE_TYPE_INDICATOR_TITLE.getGetIsoEcoField(), "0800" ));
        fields.add( new FieldIso( 7, TRANSMISSION_DATE_AND_TIME_TITLE.getGetIsoEcoField(), 
        		new SimpleDateFormat(SIMPLE_DATE_FORMAT.getGetIsoEcoField()).format(new Date()) ));
        fields.add( new FieldIso( 11, SYSTEM_TRACE_AUDIT_NUMBER_TITLE.getGetIsoEcoField(), "" + new SecureRandom().nextInt(900000) ));
        fields.add( new FieldIso( 70, NETWORK_MANAGEMENT_INFO_CODE_TITLE.getGetIsoEcoField(), "301"));
        List<FieldIso> fieldsResponse = HttpIso.pack(fields);

        if ( fieldsResponse != null ) {
            return fieldsResponse.get(0).getValue();
        } else {
            return null;
        }
    }),

    ECO_RESPONSE(()-> {
        List<FieldIso> fields = new ArrayList<>();
        fields.add( new FieldIso( 0, CUSTOM_HEADER_TITLE.getGetIsoEcoField(), CUSTOM_HEADER_VALUE.getGetIsoEcoField() ));
        fields.add( new FieldIso( 0, MESSAGE_TYPE_INDICATOR_TITLE.getGetIsoEcoField(), "0810" ));
        fields.add( new FieldIso( 7, TRANSMISSION_DATE_AND_TIME_TITLE.getGetIsoEcoField(), 
        		new SimpleDateFormat(SIMPLE_DATE_FORMAT.getGetIsoEcoField()).format(new Date()) ));
        fields.add( new FieldIso( 11, SYSTEM_TRACE_AUDIT_NUMBER_TITLE.getGetIsoEcoField(), "" + new SecureRandom().nextInt(900000) ));
        fields.add( new FieldIso( 39, RESPONSE_CODE_TITLE.getGetIsoEcoField(), "00"));
        fields.add( new FieldIso( 70, NETWORK_MANAGEMENT_INFO_CODE_TITLE.getGetIsoEcoField(), "301"));
        List<FieldIso> fieldsResponse = HttpIso.pack(fields);

        if ( fieldsResponse != null ) {
            return fieldsResponse.get(0).getValue();
        } else {
            return null;
        }
    });

    private final Supplier<String> trace;
}
