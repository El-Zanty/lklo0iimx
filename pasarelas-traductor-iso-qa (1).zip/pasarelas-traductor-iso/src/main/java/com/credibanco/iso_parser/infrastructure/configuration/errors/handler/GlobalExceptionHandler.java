package com.credibanco.iso_parser.infrastructure.configuration.errors.handler;

import com.credibanco.iso_parser.infrastructure.entrypoint.controller.out.AutorizarResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.credibanco.iso_parser.domain.ResponseFactory.*;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {


    @ExceptionHandler(TimeoutException.class)
    public ResponseEntity<AutorizarResponseDto> handleTimeout(Exception e){
        log.error("Transaction Timeout", e);
        return new ResponseEntity<>(TO_TIMEOUT.getAutorizarResponseDto(), HttpStatus.OK);
    }

    @ExceptionHandler(ExecutionException.class)
    public ResponseEntity<AutorizarResponseDto> handleExecution(Exception e){
        log.error("Execution exception for Completable future", e);
        return new ResponseEntity<>(INTERNAL_ERRORS.getAutorizarResponseDto(), HttpStatus.OK);
    }

    @ExceptionHandler(InterruptedException.class)
    public ResponseEntity<AutorizarResponseDto> handleInterrupted(Exception e){
        log.error("Thread interrupted", e);
        return new ResponseEntity<>(TO_TRANSACTION.getAutorizarResponseDto(), HttpStatus.OK);
    }

    @ExceptionHandler(ClassNotFoundException.class)
    public ResponseEntity<AutorizarResponseDto> handleClassNotFound(Exception e){
        log.error("Error en la conversión de objeto a fieldISO: ClassNotFoundException", e);
        return new ResponseEntity<>(ISO_CONVERTION_ERROR.getAutorizarResponseDto(), HttpStatus.OK);
    }

    @ExceptionHandler(NoSuchFieldException.class)
    public ResponseEntity<AutorizarResponseDto> handleNoSuchField(Exception e){
        log.error("Error en la conversión de objeto a fieldISO: NoSuchFieldException", e);
        return new ResponseEntity<>(ISO_CONVERTION_ERROR.getAutorizarResponseDto(), HttpStatus.OK);
    }

    @ExceptionHandler(IllegalAccessException.class)
    public ResponseEntity<AutorizarResponseDto> handleIllegalAccess(Exception e){
        log.error("Error en la conversión de objeto a fieldISO: IllegalAccessException", e);
        return new ResponseEntity<>(ISO_CONVERTION_ERROR.getAutorizarResponseDto(), HttpStatus.OK);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<AutorizarResponseDto> handleIO(Exception e){
        log.error("Error en la conversión de objeto a fieldISO: IOException", e);
        return new ResponseEntity<>(ISO_CONVERTION_ERROR.getAutorizarResponseDto(), HttpStatus.OK);
    }

}
