package com.credibanco.iso_parser.infrastructure.entrypoint.controller;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.credibanco.iso_parser.domain.Transaction;
import com.credibanco.iso_parser.domain.ports.in.IAuthorizeTransaction;
import com.credibanco.iso_parser.infrastructure.configuration.aop.Trace;
import com.credibanco.iso_parser.infrastructure.entrypoint.controller.out.AutorizarResponseDto;

import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class TransactionController {
	private final IAuthorizeTransaction transactionService;
	
	@PostMapping(value = "/authorization")
	@ApiOperation(value = "authorization", notes = "transaccion 200.")
	@Trace
	public AutorizarResponseDto autorization(@RequestBody Transaction trama) throws NoSuchFieldException, ClassNotFoundException, 
	IllegalAccessException, IOException, ExecutionException, InterruptedException, TimeoutException {
		return transactionService.autorization(trama);
	}
}
