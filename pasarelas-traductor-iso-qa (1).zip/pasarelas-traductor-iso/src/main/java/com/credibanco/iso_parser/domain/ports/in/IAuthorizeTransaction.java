package com.credibanco.iso_parser.domain.ports.in;

import com.credibanco.iso_parser.domain.Transaction;
import com.credibanco.iso_parser.infrastructure.entrypoint.controller.out.AutorizarResponseDto;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public interface IAuthorizeTransaction {

    public AutorizarResponseDto autorization(Transaction transaction) throws IOException, NoSuchFieldException,
            ClassNotFoundException, IllegalAccessException, ExecutionException, InterruptedException, TimeoutException;
}
