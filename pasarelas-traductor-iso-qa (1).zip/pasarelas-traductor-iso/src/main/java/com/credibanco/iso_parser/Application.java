package com.credibanco.iso_parser;

import java.util.concurrent.ExecutorService;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableConfigurationProperties
@ComponentScan({"com.credibanco.iso_parser", "com.credibanco.isopacker"})
public class Application implements DisposableBean{
	
	@Autowired
	ExecutorService executorService;
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class);
	}

	@Override
	public void destroy() throws Exception {
		executorService.shutdownNow();
	}
}
