package com.credibanco.iso_parser.domain;

public class PointOfServiceEntryMode extends LogicGeneradorMap {

	private String tipoLectura;
	private String capacidadPin;
	
	public String getTipoLectura() {
		return tipoLectura;
	}
	public void setTipoLectura(String tipoLectura) {
		this.tipoLectura = tipoLectura;
	}
	public String getCapacidadPin() {
		return capacidadPin;
	}
	public void setCapacidadPin(String capacidadPin) {
		this.capacidadPin = capacidadPin;
	}
}
