package com.credibanco.iso_parser.infrastructure.driveradapter.socket_sv.dtos;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum IsoEnums {
    CUSTOM_HEADER_TITLE("CustomHeader"),
    CUSTOM_HEADER_VALUE( "ISO026000010"),
    MESSAGE_TYPE_INDICATOR_TITLE("Message Type Indicator"),
    TRANSMISSION_DATE_AND_TIME_TITLE("Transmission date & time"),
    SYSTEM_TRACE_AUDIT_NUMBER_TITLE ("Systems trace audit number"),
    NETWORK_MANAGEMENT_INFO_CODE_TITLE("Network management Information code"),
    RESPONSE_CODE_TITLE("Response code"),
    SIMPLE_DATE_FORMAT("MMddHHmmss");

    private final String getIsoEcoField;
}
