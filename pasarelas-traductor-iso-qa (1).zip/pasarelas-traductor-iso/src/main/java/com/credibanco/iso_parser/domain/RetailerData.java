package com.credibanco.iso_parser.domain;

public class RetailerData extends LogicGeneradorMap {

	private String identificacionEstablecimiento;
	private String grupoEstablecimiento;
	private String regionEstablecimiento;
	
	public String getIdentificacionEstablecimiento() {
		return identificacionEstablecimiento;
	}
	public void setIdentificacionEstablecimiento(String identificacionEstablecimiento) {
		this.identificacionEstablecimiento = identificacionEstablecimiento;
	}
	public String getGrupoEstablecimiento() {
		return grupoEstablecimiento;
	}
	public void setGrupoEstablecimiento(String grupoEstablecimiento) {
		this.grupoEstablecimiento = grupoEstablecimiento;
	}
	public String getRegionEstablecimiento() {
		return regionEstablecimiento;
	}
	public void setRegionEstablecimiento(String regionEstablecimiento) {
		this.regionEstablecimiento = regionEstablecimiento;
	}
	
}
