package com.credibanco.iso_parser.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardAcceptorIdentificationCode extends LogicGeneradorMap{
	
	private String cuotas;
	private String sub2;
	private String codigoComercio;
	
}
