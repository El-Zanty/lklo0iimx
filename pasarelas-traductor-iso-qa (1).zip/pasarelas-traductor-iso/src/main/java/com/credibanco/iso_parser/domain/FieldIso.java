package com.credibanco.iso_parser.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FieldIso {

	private int id; 
	private String name;
	private String value;
	private String packedValue;
	
	public FieldIso() {
		super();
	}

	@JsonIgnore
	public FieldIso(int id, String name, String value) {
		super();
		this.id = id;
		this.name = name;
		this.value = value;
//		System.out.println("this.toString:: " + this.toString());
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getPackedValue() {
		return packedValue;
	}
	public void setPackedValue(String packedValue) {
		this.packedValue = packedValue;
	}

	@Override
	public String toString() {
		String theValue = this.value;
		if(this.id == 35) {
			String[] splitedValue = this.value.split("=");
			if(splitedValue.length > 0) {
				String cardValue = splitedValue[0].trim();
				if(cardValue.length() == 16) {
					theValue = cardValue.substring(0, 6) + "******" + cardValue.substring(12);
				}else {
					theValue = "**Dato sensible**";
				}
			}else {
				theValue = "**Dato sensible**";
			}
		}
		return "FieldIso [id=" + id + ", name=" + name + ", value=" + theValue + "]";
	}
	
}
