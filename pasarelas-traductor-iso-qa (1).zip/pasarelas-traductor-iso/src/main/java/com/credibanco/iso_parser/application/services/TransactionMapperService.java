package com.credibanco.iso_parser.application.services;

import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.credibanco.iso_parser.domain.DataField;
import com.credibanco.iso_parser.domain.FieldIso;
import com.credibanco.iso_parser.domain.LogicGeneradorMap;
import com.credibanco.iso_parser.domain.Transaction;
import com.credibanco.iso_parser.infrastructure.configuration.FieldsProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class TransactionMapperService {
	
	public static final int MAP_OF_VALUES = 1;
	public static final int SIMPLE_VALUE = 2;
	
	private final FieldsProperties fieldsProperties;
	
	ObjectMapper objectMapper = new ObjectMapper();
	
	public List<FieldIso> getList(Transaction transaction) throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException, IOException{
		
		List<FieldIso> fieldsIso = new ArrayList<>();
		Map<String, DataField> dataFields = fieldsProperties.getIsoMap();
		
		//Obtiene instancia de la clase 
		Class<?> clazz = Class.forName(this.getClassName(transaction));
		
		for (String fieldName: fieldsProperties.getTransaction()) {
			// Obtener los atributos de los objetos
			Field field = clazz.getDeclaredField( fieldName );
			field.setAccessible(true);
			
			DataField dataField = dataFields.get(field.getName());
			
			if (field.get(transaction) instanceof LogicGeneradorMap) {
				LogicGeneradorMap instance = ( LogicGeneradorMap ) field.get(transaction);
				String value = this.getStringSonValues(instance);
				
				if(dataField.getFieldNumber() == 90) {
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), String.format( dataField.getFormat(), new BigInteger (value) ) ) );
				}
				else if ( dataField.getFormat().contains("d") ) {
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), String.format( dataField.getFormat(), Integer.parseInt( value ) ) ) );
				} else {
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), String.format( dataField.getFormat(), value ) ) );
				}
			} else if ( field.get(transaction) instanceof String && dataField.getType() == SIMPLE_VALUE  ) {
				//añadir formato
				String value = ( String )field.get(transaction);
				if ( dataField.getFormat().contains("d") ) {
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), String.format( dataField.getFormat(), Long.parseLong( value ) ) ) );
				} else {
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), String.format( dataField.getFormat(), value ) ) );
				}
			} else if ( (field.get( transaction ) instanceof LocalDate || field.get( transaction ) instanceof LocalTime) && dataField.getType() == SIMPLE_VALUE  ) {
				//añadir formato
				DateTimeFormatter format = DateTimeFormatter.ofPattern( dataField.getFormat() );
				if ( field.get( transaction ) instanceof LocalDate ) {
					LocalDate value = ( LocalDate )field.get( transaction );
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), value.format( format  ) ) );
				} else if ( field.get( transaction ) instanceof LocalTime ) {
					LocalTime value = ( LocalTime )field.get( transaction );
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), value.format( format  ) ) );
				} else if ( field.get( transaction ) instanceof LocalDateTime ) {
					LocalDateTime value = ( LocalDateTime )field.get( transaction );
					fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), value.format( format  ) ) );
				}
			} else if ( (field.get( transaction ) instanceof Date) && dataField.getType() == SIMPLE_VALUE  ) {
				//añadir formato
				Date value = ( Date )field.get( transaction );
				SimpleDateFormat format = new SimpleDateFormat( dataField.getFormat() );
				fieldsIso.add( new FieldIso( dataField.getFieldNumber(), dataField.getFieldName(), format.format(value) ) );
			} 
			
		}
		fieldsIso.add(new FieldIso(0, "CustomHeader", "ISO026000010"));
		return fieldsIso;
	}
	
	private <T> String getStringSonValues(T transactionObj) throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException, IOException{
		
		Class<?> clazz = Class.forName(this.getClassName(transactionObj));
		Map<String, List<String>> fieldsInfo = fieldsProperties.getSubFields();
		Map<String, DataField> dataFields = fieldsProperties.getIsoMap();
		List<String> fieldInfo = fieldsInfo.get(this.getSimpleClassName(transactionObj));
		StringBuilder bld = new StringBuilder();
		
		for (int i = 0; i < fieldInfo.size(); i++) {
			String fieldName = fieldInfo.get(i);
			Field field = clazz.getDeclaredField( fieldName );
			field.setAccessible(true);
			DataField dataField = dataFields.get(this.getSimpleClassName(transactionObj)+"-"+field.getName());
			if ( field.get( transactionObj ) instanceof String) {
				String value = ( String )field.get( transactionObj );
				if ( dataField.getType() == MAP_OF_VALUES  ) {
					Map <String, String> valueOfValues = objectMapper.readValue(dataField.getValues().toString(), HashMap.class) ;
					bld.append( valueOfValues.get( value ));
				} else if ( dataField.getType() == SIMPLE_VALUE  ) {
				    if ( dataField.getFormat() == null ) {
				    	bld.append(value);
					} else if ( dataField.getFormat().contains("d") ) {
						bld.append(String.format( dataField.getFormat(), Integer.parseInt( value ) ));
					} else if ( dataField.getFormat().contains("s") ) {
						bld.append(String.format( dataField.getFormat(), value ));
					}
				}
			}
		}
		return bld.toString();
	} 
	
	private <T> String getSimpleClassName(T objectFind) {
	    Class<?> enclosingClass = objectFind.getClass().getEnclosingClass();
	    if (enclosingClass != null) {
	        return enclosingClass.getSimpleName();
	    } else {
	        return objectFind.getClass().getSimpleName();
	    }
	}
	
	private <T> String getClassName(T objectFind) {
		Class<?> enclosingClass = objectFind.getClass().getEnclosingClass();
		if (enclosingClass != null) {
			return enclosingClass.getName();
		} else {
			return objectFind.getClass().getName();
		}
	}

}
