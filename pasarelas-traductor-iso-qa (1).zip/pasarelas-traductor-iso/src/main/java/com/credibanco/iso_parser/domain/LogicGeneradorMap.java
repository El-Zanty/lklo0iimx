package com.credibanco.iso_parser.domain;

public class LogicGeneradorMap {

}
