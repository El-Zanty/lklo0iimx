package com.credibanco.iso_parser.application.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.MissingResourceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.credibanco.iso_parser.domain.FieldIso;
import com.credibanco.iso_parser.domain.PackIso;
import com.credibanco.iso_parser.domain.UnPackIso;
import com.credibanco.isopacker.dtos.PackerRequestModel;
import com.credibanco.isopacker.model.DataFieldModel;
import com.credibanco.isopacker.services.IISOPackerService;

//Almost an adapter pattern
@Component
public class HttpIso {
	
	private static final Logger LOG = LoggerFactory.getLogger(HttpIso.class);

	private static IISOPackerService isoPackerService;

	@Autowired
	public HttpIso(IISOPackerService isoPackerService) {
		HttpIso.isoPackerService = isoPackerService;
	}

	public static List<FieldIso> pack(List<FieldIso> fields) {
		
		try {
			PackIso packIso = new PackIso();
			packIso.setFields(fields);
			PackerRequestModel prm = buildPackerRequestModelFromFields(packIso);
			List<DataFieldModel> dataFieldModelList = isoPackerService.pack(prm);
			
			if( dataFieldModelList != null && !dataFieldModelList.isEmpty() ){
				List<FieldIso> responseFields = buildFieldIsoListFromDataFieldModelList(dataFieldModelList);
				return responseFields;
			} else {
				return null;
			}

		} catch (MissingResourceException e) {
			LOG.error("pack()", e);
		} catch (Exception e) {
			LOG.error("pack()", e);
		}
		return null;
	}
	
	private static PackerRequestModel buildPackerRequestModelFromFields(PackIso packIso) {
		PackerRequestModel prm = new PackerRequestModel();
		List<DataFieldModel> dataFieldModelList = new ArrayList<>();
		for(FieldIso fieldIso: packIso.getFields()) {
			DataFieldModel dfm = new DataFieldModel();
			dfm.setId(fieldIso.getId());
			dfm.setName(fieldIso.getName());
			dfm.setPackedValue(fieldIso.getPackedValue());
			dfm.setValue(fieldIso.getValue());
			dataFieldModelList.add(dfm);
		}
		prm.setFields(dataFieldModelList);
		prm.setOptions(packIso.getOptions());
		
		return prm;
	}
	
	private static List<FieldIso> buildFieldIsoListFromDataFieldModelList(List<DataFieldModel> dataFieldModelList) {
		List<FieldIso> fieldIsoList = new ArrayList<>();
		
		for(DataFieldModel dfm : dataFieldModelList) {
			FieldIso fieldIso = new FieldIso();
			fieldIso.setId(dfm.getId());
			fieldIso.setName(dfm.getName());
			fieldIso.setPackedValue(dfm.getPackedValue());
			fieldIso.setValue(dfm.getValue());
			
			fieldIsoList.add(fieldIso);
		}
		
		return fieldIsoList;
	}
	
	public static List<FieldIso> unPack(UnPackIso trama) {
		
		try {
			
			PackerRequestModel prm = new PackerRequestModel();
			prm.setTrace(trama.getTrace());
			prm.setOptions(trama.getOptions());
			List<DataFieldModel> dfmList = isoPackerService.unPack(prm);
			
			if( dfmList != null && !dfmList.isEmpty() ){
				List<FieldIso> responseFields = buildFieldIsoListFromDataFieldModelList(dfmList);
				return responseFields;
			} else {
				return null;
			}
		} catch (Exception e) {
			LOG.error("unPack()", e);
		}
		return null;
	}
	
}
