package com.credibanco.iso_parser.infrastructure.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.undertow.UndertowServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UndertowConfiguration {
	
	@Value("${server.undertow.threads.io}")
	private Integer ioThreads;
	  
	@Value("${server.undertow.threads.worker}")
	private Integer taskThreads;
	
	@Bean 
	public UndertowServletWebServerFactory embeddedServletContainerFactory() {
		  UndertowServletWebServerFactory factory = new UndertowServletWebServerFactory();
		  factory.setIoThreads(ioThreads);
		  factory.setWorkerThreads(taskThreads);
		  return factory;
	}

}
