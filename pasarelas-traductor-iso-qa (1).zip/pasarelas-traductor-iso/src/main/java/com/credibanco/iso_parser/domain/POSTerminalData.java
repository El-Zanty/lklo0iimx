package com.credibanco.iso_parser.domain;

public class POSTerminalData extends LogicGeneradorMap {

	private String terminalOwnerFIID;
	private String terminalLogicalNetwork;
	private String terminalTimeOffset;
	private String pseudoTerminalID;
	
	public String getTerminalOwnerFIID() {
		return terminalOwnerFIID;
	}
	public void setTerminalOwnerFIID(String terminalOwnerFIID) {
		this.terminalOwnerFIID = terminalOwnerFIID;
	}
	public String getTerminalLogicalNetwork() {
		return terminalLogicalNetwork;
	}
	public void setTerminalLogicalNetwork(String terminalLogicalNetwork) {
		this.terminalLogicalNetwork = terminalLogicalNetwork;
	}
	public String getTerminalTimeOffset() {
		return terminalTimeOffset;
	}
	public void setTerminalTimeOffset(String terminalTimeOffset) {
		this.terminalTimeOffset = terminalTimeOffset;
	}
	public String getPseudoTerminalID() {
		return pseudoTerminalID;
	}
	public void setPseudoTerminalID(String pseudoTerminalID) {
		this.pseudoTerminalID = pseudoTerminalID;
	}

}
