package com.credibanco.iso_parser.domain;

public class ProcessingCode extends LogicGeneradorMap{

	private String codigoTransaccion;
	private String tipoCuentaRetiro;
	private String tipoCuentaDeposito;
	
	public String getCodigoTransaccion() {
		return codigoTransaccion;
	}
	public void setCodigoTransaccion(String codigoTransaccion) {
		this.codigoTransaccion = codigoTransaccion;
	}
	public String getTipoCuentaRetiro() {
		return tipoCuentaRetiro;
	}
	public void setTipoCuentaRetiro(String tipoCuentaRetiro) {
		this.tipoCuentaRetiro = tipoCuentaRetiro;
	}
	public String getTipoCuentaDeposito() {
		return tipoCuentaDeposito;
	}
	public void setTipoCuentaDeposito(String tipoCuentaDeposito) {
		this.tipoCuentaDeposito = tipoCuentaDeposito;
	}
	
}
