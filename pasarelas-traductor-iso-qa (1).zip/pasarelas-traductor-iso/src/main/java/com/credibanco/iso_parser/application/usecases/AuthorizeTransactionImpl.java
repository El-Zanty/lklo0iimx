package com.credibanco.iso_parser.application.usecases;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import com.credibanco.iso_parser.domain.ports.in.IAuthorizeTransaction;
import com.credibanco.iso_parser.domain.ports.out.TransactionAuthorizationRepository;
import com.credibanco.iso_parser.application.services.TransactionMapperService;
import com.credibanco.iso_parser.domain.FieldIso;
import com.credibanco.iso_parser.domain.Transaction;
import com.credibanco.iso_parser.infrastructure.configuration.ErrorCodes;
import com.credibanco.iso_parser.infrastructure.entrypoint.controller.out.AutorizarResponseDto;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class AuthorizeTransactionImpl implements IAuthorizeTransaction {

	private final TransactionAuthorizationRepository transactionAuthorizationRepository;
	private final TransactionMapperService transactionMapperService;
	private final ErrorCodes errorCodes;

	public AutorizarResponseDto autorization(Transaction transaction) throws IOException, NoSuchFieldException,
			ClassNotFoundException, IllegalAccessException, ExecutionException, InterruptedException, TimeoutException {
		log.info("Request to SV ----> {}", transaction.toString());
		List<FieldIso> fieldsList = null;
		try {
				fieldsList = transactionMapperService.getList(transaction);
		    } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException | IOException | RuntimeException e) {
			log.error("Error parsing to ISO ");
			throw e;
		    }
		Date startDate = new Date();
		List<FieldIso> responseList = transactionAuthorizationRepository.sendToAuthorize(fieldsList);
		return buildResponse(fieldsList, responseList, startDate);
	}

	private AutorizarResponseDto buildResponse(List<FieldIso> listRequest, List<FieldIso> listResponse, Date createDate) {
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			dateFormat.setTimeZone(TimeZone.getTimeZone("America/Bogota"));
		    AutorizarResponseDto response = new AutorizarResponseDto();
		    String cardNumberTrack2 = "------------1111";
			for (FieldIso fieldIso : listRequest) {
				if( fieldIso.getId() == 0 && fieldIso.getName().equalsIgnoreCase("Message Type Indicator") ) {
					response.setMti(fieldIso.getValue());
				}else if(fieldIso.getId() == 7 && fieldIso.getName().equalsIgnoreCase("Transmission date & time") ) {
					response.setTransmission_date_time(fieldIso.getValue());
				}else if(fieldIso.getId() == 11 && fieldIso.getName().equalsIgnoreCase("Systems trace audit number")) {
					response.setSystemTrace(fieldIso.getValue());
				}else if(fieldIso.getId() == 35 && fieldIso.getName().equalsIgnoreCase("Track 2 data")) {
            		cardNumberTrack2 = fieldIso.getValue();
            	}
			}
			for(FieldIso fieldIso: listResponse) {
				if( fieldIso.getId() == 38 ) {
					response.setAutorizationCode(fieldIso.getValue());
				}else if( fieldIso.getId() == 39 ) {
					response.setResponseCode(fieldIso.getValue());
				}else if(fieldIso.getId() == 0 && fieldIso.getName().equalsIgnoreCase("Response Trace")) {
					response.setIso(maskTrace(fieldIso.getValue(), cardNumberTrack2));
				}else if(fieldIso.getId() == 0 && fieldIso.getName().equalsIgnoreCase("Request key")) {
					response.setChannel(fieldIso.getValue());
				}else if(fieldIso.getId() == 0 && fieldIso.getName().equalsIgnoreCase("Request Trace")) {
					response.setSentTrace(maskTrace(fieldIso.getValue(), cardNumberTrack2));
				}
			}
			response.setCreateDate(createDate);
			response.setEndDateAutorizador(dateFormat.format(new Date()));
			String message = errorCodes.getSvErrorCodes().get(response.getResponseCode());
			response.setMenssage(message != null? message: "Error no especificado");
			response.setStartDateAutorizador(dateFormat.format(createDate));
			log.info("Response ---> {}", response.toString());
			return response;
	}

	private String maskTrace(String trace, String cardNumberTrack2) {
		int indexEqual = cardNumberTrack2.indexOf('=');

		String cardNumber = cardNumberTrack2.substring(0, indexEqual) ;
		StringBuilder sb=new StringBuilder("");
		for(int i=0; i< indexEqual-4-6;++i) {
			sb.append('*');
		}
		String filler = sb.toString();
		String maskedCard = String.format("%s%s%s", cardNumberTrack2.substring(0,6), filler, cardNumberTrack2.substring(indexEqual-4, indexEqual));

		String firstMask = trace.replace(cardNumber+"=", maskedCard+"=");
		String finalMask = firstMask.replaceAll("! C000026 \\d{3}", "! C000026 ***");
		finalMask = finalMask.replaceAll("! C000026 \\*\\*\\*\\d", "! C000026 ****");
		return finalMask;
	}

}
