# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.13.0.0-RELEASE] - 2023-03-05

### Added

- Arquitectura límpia
- Clase de configuración de puertos
- Se instanció el SocketSmartVista en el contenedor de Spring
- Se creo un método @PostConstruct para iniciar el socket
- Se creo un método de reconexión
- Se creó una clase para traer variables de properties y que quedaran en variables tipo Map

### Changed

- Se cambió el executorService para la creación de hilos
- Se reemplazó redis pub/sub por la librería CompletableFuture
- Se reemplazó las variables en properties a un archivo yml 

### Removed

- Se quitaron clases de creación de Socket
- Se quitó redis pub/sub

[1.13.0.0-RELEASE]: https://gogs.apps-pruebas.credibanco.com/Credibanco/pasarelas-traductor-iso/compare/1.13.0.0-RELEASE...HEAD
