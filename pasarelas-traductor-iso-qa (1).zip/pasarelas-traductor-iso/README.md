# Traductor-ISO

Api que transforma de apiRest a ISO8583

## Usos

* Envío de transacciones al Swith transaccional

## Diagramas de aplicación

### Diagrama de contexto

![Context Image](/img/Contexto.png)

### Diagrama de Clases

![Context Image](/img/Clases.png)

### Construido con:
Lista de tecnologías empleadas en la elaboración de la aplicación

* Spring Boot
* Java

## Getting Started

### Prerequisitos

Para la correcta ejecución en la máquina local se necesitan de las siguientes configuraciones:

* Conexión al switch transaccional por socket (ip - puerto)

### Instalación

Pasos para su ejecución luego de la configuración del ambiente

```bash
mvn project run
```

## Contextos

### Contrato swagger



## Ejemplos compra tokenizada

### Tokenized request

```
{
    "retrievalReferenceNumber":"{{rrn}}", 
    "transmissionDateTime":"{{currentdate}}",
    "systemsTraceAuditNumber":"{{systemsTraceAuditNumber}}",
    "localTransactionTime":"{{currentLocalTime}}",
	"localTransactionDate":"{{currentLocaldate}}",
	"captureDate":"{{currentLocaldate}}",
    "messageType":{
        "claseMensaje": "02",
        "funcionMensaje": "00"
    },
	"processingCode":{
        "codigoTransaccion":"00",
	    "tipoCuentaRetiro":"00",
	    "tipoCuentaDeposito":"Tarjeta Credito"
    },
    "additionalData":{
        "IVA":0,
	    "baseDevolucion":0,
	    "IAC":"0"
    },
	"transactionAmount": 123000,
	"merchantType":"5598",
	"entryMode":{
        "tipoLectura": "01",
        "capacidadPin": "2"
    },
	"posConditionCode":"59",
	"acquiringInstitutioncode":"10000000090",
	"track2":{
        "discretionaryData":"", 
        "endSentinel":"", 
        "expirationDate":"2212", 
        "longitudinalRedundancyCheck":"", 
        "pan":"476134*********0043", 
        "serviceCode":""
    },
    "terminalIdentification":"00000541",
	"cardAcceptorIdentificationCode":{
        "cuotas": "1",
	    "sub2": "00",
	    "codigoComercio": "014331060"
    },
	"cardAcceptorName":{
        "terminalOwnerName":"LA BIFERIA",
	    "terminalCity":"11001BOGOTA",
	    "terminalState":"CUN",
	    "terminalCountry":"CO"
    },
	"retailerData":{
        "identificacionEstablecimiento":"014331060",
	    "grupoEstablecimiento":"0000",
	    "regionEstablecimiento":"0003"  
    },
	"transactionCurrencyCode":170,
	"posTerminalData":{
        "terminalOwnerFIID":"0090",
	    "terminalLogicalNetwork":"TES2",
	    "terminalTimeOffset":"0000",
	    "pseudoTerminalID":"TES2"
    },
	"posCardIssuer":{
        "cardIssuerFIID":"    ",
	    "cardlogicalNetword":"TES2",
	    "category":"0",
	    "saveAccountIndicator":"00",
	    "interchangeResponseCode":"        "
    },
	"additionalDataTokens":"& 0000200048! C000026                   70      ",
	"receivingInstitutionIdentificationCode":"           ",
	"posBachShiftData":"000000000",
	"posSettlementData":"  B24 B24 1 ",
	"reservedPrivate121":" ",
	"reservedPrivate123":" ",
	"reservedPrivate126":" "
}
```

### Tokenized response

```

```

## [Changelog](CHANGELOG.md)

